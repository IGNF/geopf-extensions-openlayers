# Photo Sphere Viewer / Plan2 Plugin

[![NPM version](https://img.shields.io/npm/v/@photo-sphere-viewer/plan2-plugin?logo=npm)](https://www.npmjs.com/package/@photo-sphere-viewer/plan2-plugin)
[![NPM Downloads](https://img.shields.io/npm/dm/@photo-sphere-viewer/plan2-plugin?color=f86036&label=npm&logo=npm)](https://npmtrends.com/@photo-sphere-viewer/plan2-plugin)
[![jsDelivr Hits](https://img.shields.io/jsdelivr/npm/hm/@photo-sphere-viewer/plan2-plugin?color=%23f86036&logo=jsdelivr)](https://www.jsdelivr.com/package/npm/@photo-sphere-viewer/plan2-plugin)
[![Bundle size](https://img.shields.io/bundlephobia/minzip/@photo-sphere-viewer/plan2-plugin?logo=webpack&label=gzip)](https://bundlephobia.com/package/@photo-sphere-viewer/plan2-plugin)

Photo Sphere Viewer plugin to add a geographic map (via OpenLayers).

## Documentation

https://photo-sphere-viewer.js.org/plugins/plan2.html

## License

This library is available under the MIT license.
