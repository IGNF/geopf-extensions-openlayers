export default IsoDOM;
declare namespace IsoDOM {
    function _addUID(id: string): string;
    function _createMainContainerElement(): HTMLElement;
    function _createShowIsoPictoElement(): HTMLElement;
    function _createIsoPanelElement(): HTMLElement;
    function _createIsoPanelDivElement(): HTMLDivElement;
    function _createDrawingButtonsPluginDiv(): HTMLDivElement;
    function _createIsoPanelFormElement(): HTMLElement;
    function _createIsoPanelResultsElement(): HTMLElement;
    function _addIsoResultsValuesElement(results: any, computeOptions: any, fconvert: Function): HTMLElement;
    function _createIsoWaitingElement(): HTMLElement;
    function _createIsoPanelFooterElement(): HTMLElement;
    function _createIsoPanelFormTypeChoiceElement(): HTMLElement;
    function _createIsoPanelFormTypeChoiceChronElement(checked: boolean): HTMLElement;
    function _createIsoPanelFormTypeChoiceDistElement(checked: boolean): HTMLElement;
    function _createIsoPanelFormValueIsochronElement(checked: boolean): HTMLElement;
    function _createIsoPanelFormLabelIsodistanceElement(): HTMLElement;
    function _createIsoPanelFormValueIsodistanceElement(checked: boolean): HTMLElement;
    function _createIsoPanelFormModeChoiceTransportElement(transports: any[]): HTMLElement;
    function _createIsoPanelFormModeChoiceDirectionElement(directions: any[]): HTMLElement;
    function _createShowIsoExclusionsPictoElement(): HTMLElement;
    function _createIsoPanelFormExclusionOptionsElement(exclusions: any): HTMLElement;
    function _createIsoSubmitFormElement(): HTMLElement;
    function _createIsoFormResetElement(): HTMLElement;
}
//# sourceMappingURL=IsocurveDOM.d.ts.map