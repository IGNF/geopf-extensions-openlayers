export default TerritoriesDOM;
declare namespace TerritoriesDOM {
    function _addUID(id: string): string;
    function createDraggableElement(elementDraggable: any, context: any): any;
    function _createMainContainerElement(): HTMLElement;
    function _createShowTerritoriesPictoElement(): HTMLElement;
    function _createTerritoriesPanelElement(): HTMLElement;
    function _createTerritoriesPanelDivElement(): HTMLDivElement;
    function _createTerritoriesPanelOptionsElement(title: any, description: any): ChildNode | null;
    function _createTerritoriesPanelMenuViewsDivElement(title: any, description: any): HTMLDivElement;
    function _createTerritoriesButtonOpenMenuViewsElement(title: any, description: any): HTMLButtonElement;
    function _createTerritoriesPanelMenuViewsElement(title: any): HTMLDialogElement;
    function _createTerritoriesMenuAddViewElement(title: any): ChildNode | null;
    function _createTerritoriesMenuListViewElement(): ChildNode | null;
    function _createTerritoriesElement(): HTMLDivElement;
    function _createTerritoryEntry(o: any): ChildNode | null | undefined;
    function _createTerritoryView(o: any): ChildNode | null | undefined;
}
//# sourceMappingURL=TerritoriesDOM.d.ts.map