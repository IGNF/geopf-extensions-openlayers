export default LayerImportDOM;
declare namespace LayerImportDOM {
    function _addUID(id: string): string;
    function _createLoadingElement(): HTMLElement;
    function _createMainContainerElement(): HTMLElement;
    function _createShowImportPictoElement(): HTMLElement;
    function _createImportPanelElement(): HTMLElement;
    function _createImportPanelDivElement(): HTMLDivElement;
    function _createImportPanelFormElement(): HTMLElement;
    function _createImportTypeLineElement(importTypes: any[]): HTMLElement;
    function _createImportWaitingElement(): HTMLElement;
    function _createImportStaticParamsContainer(currentType: string): HTMLElement;
    function _createStaticNameLabel(): HTMLElement;
    function _createStaticModeChoiceDiv(): HTMLElement;
    function _createStaticLocalChoiceDiv(): HTMLElement;
    function _createStaticUrlChoiceDiv(): HTMLElement;
    function _createStaticLocalInputDiv(): HTMLElement;
    function _createStaticLocalInputLabel(): HTMLElement;
    function _createStaticLocalInput(): HTMLElement;
    function _createStaticUrlInputDiv(): HTMLElement;
    function _createStaticUrlInputLabel(): HTMLElement;
    function _createStaticUrlInput(): HTMLElement;
    function _createServiceParamsContainer(currentType: string): HTMLElement;
    function _createServiceUrlDiv(): HTMLElement;
    function _createServiceUrlInputLabel(): HTMLElement;
    function _createServiceUrlInput(): HTMLElement;
    function _createImportSubmitFormElement(): HTMLElement;
    function _createImportGetCapPanelElement(): HTMLElement;
    function _createImportGetCapPanelHeaderElement(): HTMLElement;
    function _createImportGetCapResultsContainer(): HTMLElement;
    function _addImportGetCapResultListRubrique(title: any, container: any): any;
    function _addImportGetCapResultRubrique(title: any, container: any): any;
    function _addImportGetCapResultListLayer(container: any): any;
    function _addImportGetCapResultLayer(description: any, id: any, container: any): any;
    function _createImportMapBoxPanelElement(): HTMLElement;
    function _createImportMapBoxPanelHeaderElement(): HTMLElement;
    function _createImportMapBoxResultsContainer(): HTMLElement;
}
//# sourceMappingURL=LayerImportDOM.d.ts.map